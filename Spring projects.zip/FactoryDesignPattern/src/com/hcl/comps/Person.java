package com.hcl.comps;

public interface Person {

	public void dotask();
	
}
