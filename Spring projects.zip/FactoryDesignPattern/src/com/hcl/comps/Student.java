package com.hcl.comps;

public class Student implements Person {

	@Override
	public void dotask() {
		
		System.out.print("student doing study");
		
	}

}
