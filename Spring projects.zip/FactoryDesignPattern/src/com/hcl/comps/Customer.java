package com.hcl.comps;

public class Customer implements Person {

	@Override
	public void dotask() {
//
		System.out.print("customer buying product");
	}

}
