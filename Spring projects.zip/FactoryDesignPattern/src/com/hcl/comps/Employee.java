package com.hcl.comps;

public class Employee implements Person {

	@Override
	public void dotask() {

		System.out.print("employee doing job");
	}

}
