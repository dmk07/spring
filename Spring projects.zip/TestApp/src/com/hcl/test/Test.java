package com.hcl.test;

public class Test {

	public static void main(String[] args) {
	
	System.out.print("test");
	
	}

}
