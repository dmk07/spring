package com.hcl.interfaces;

public interface Courier {

	public String deliver(int orderId);
	
}
