package com.hcl.interfaces;

public final class Bluedart implements Courier{

	@Override
	public String deliver(int orderId) {
		
		
		return "Product will be delivered by Bluedart Services..";
	}

}
