package com.hcl.interfaces;

public  final class DTDC implements Courier {

	@Override
	public String deliver(int orderId) {
	
		
		return "Product will be delivered by DTDC Services..";
	}

}
