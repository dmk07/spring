package com.hcl.interfaces;

public final class DFL implements Courier {

	@Override
	public String deliver(int orderId) {
		
		
		return "Product will be delivered by DFL Services..";
	}
}
