package com.hcl.composition;

public class Student {

	public String sname;
	public String scity;

	public void setSname(String sname) {
		this.sname = sname;
	}

	public void setScity(String scity) {
		this.scity = scity;
	}

	public String getStudent() {
		return " " + sname + " " + scity;
	}

}
