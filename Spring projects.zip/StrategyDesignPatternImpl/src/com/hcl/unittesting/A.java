package com.hcl.unittesting;

public class A {
		
		public int m1()
		{
			return 10;
		}
		
		public int m2()
		{
			return 100;
		}
}
