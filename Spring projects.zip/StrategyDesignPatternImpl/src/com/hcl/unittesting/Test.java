package com.hcl.unittesting;

public class Test {

	public static void main(String[] args) {

		B b = new B();
		int a = b.m3();
		int aa = b.m4();

		System.out.println(a);
		System.out.println(aa);

	}

}
