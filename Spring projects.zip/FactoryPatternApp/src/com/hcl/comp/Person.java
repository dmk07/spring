package com.hcl.comp;

public interface Person {
	
	public void doTask();

}
