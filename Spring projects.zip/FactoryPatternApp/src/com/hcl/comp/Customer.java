package com.hcl.comp;

public class Customer implements Person {

	@Override
	public void doTask() {
		
		System.out.print("customer buying product");		
	}

}
