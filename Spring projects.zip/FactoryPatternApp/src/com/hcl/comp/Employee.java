package com.hcl.comp;

public class Employee implements Person{

	@Override
	public void doTask() {

		System.out.print("employee doing job");
		
	}

}
