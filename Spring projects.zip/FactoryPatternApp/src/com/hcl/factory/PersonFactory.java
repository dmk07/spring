package com.hcl.factory;

import com.hcl.comp.Customer;
import com.hcl.comp.Employee;
import com.hcl.comp.Person;
import com.hcl.comp.Student;

public class PersonFactory {
	
	public static Person getFactory(String type)
	{
		Person person=null;
		
		 if(type.equalsIgnoreCase("student"))
		 {
			 person=new Student();
		 }else if(type.equalsIgnoreCase("employee"))
		 {
			 person=new Employee();
		 }else if(type.equalsIgnoreCase("customer"))
		 {
			 person=new Customer();
		 }
		 else
			 throw new IllegalArgumentException("invalid input");
		return person;
		
	}
	

}
