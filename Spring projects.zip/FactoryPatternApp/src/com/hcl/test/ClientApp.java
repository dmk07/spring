package com.hcl.test;

import com.hcl.comp.Person;
import com.hcl.factory.PersonFactory;

public class ClientApp {

	public static void main(String[] args) {
		
		Person per=PersonFactory.getFactory("student");
		
		per.doTask();
		
		Person per1=PersonFactory.getFactory("employee");
		 per1.doTask();
	}

}
