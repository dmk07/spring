package com.hcl.module.rule1.inheritance.fragile;

public class A {
	// if i will chage the return type of m1 method
	// then it should be change where this class in inhertied
	
	
	
	public float m1()
	{
		return 100;
	}

}
