package com.hcl.module.rule1.inheritance.fragile;

public class C extends B{

//	public int m1()
//	{
//		return 10000;
//	}

}
