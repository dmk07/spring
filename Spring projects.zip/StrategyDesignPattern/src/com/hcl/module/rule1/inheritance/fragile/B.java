package com.hcl.module.rule1.inheritance.fragile;

public class B extends A {
//	@Override
//	public int m1()
//	{
//		return 1000; // error in this method
//	}

}
