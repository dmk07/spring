package com.hcl.module.rule1.inheritance.tightcoupling;

public class Bludart {

	private int oid;
	public int deliver(int oid)
	{
		System.out.print(oid);
	return oid;
	}
}
