package com.hcl.module.rule1.inheritance.unittesting;

public class A {

	public int m1()
	{
		return 100;
	}
	public int m2()
	{
		return 1000;
	}
	
}
