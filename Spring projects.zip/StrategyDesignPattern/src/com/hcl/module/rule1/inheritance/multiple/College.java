package com.hcl.module.rule1.inheritance.multiple;

public class College {
	
	String college;
	public void m1() {
		
	}
	
}
