package com.hcl.module.rule1.inheritance.fragile;

public class D extends B {

//	public int m1()
//	{
//		return 0;
//	}

}
